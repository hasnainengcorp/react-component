import React from "react";
import Header  from "./Components/Header";
import Footer from "./Components/Footer"
import GithubUser from "./Components/GithubUser";
function App() {
  return (
    <div className="App">
      <div>Heloo World</div>
     <GithubUser></GithubUser>
      <Footer></Footer>
  

    </div>
  );
}

export default App;